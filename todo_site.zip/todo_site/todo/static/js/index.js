function showNotification(message, isError = false) {
    const notification = document.querySelector('.alert');
    const spinner = document.getElementById('spinner');
    const checkmark = document.getElementById('checkmark');
    const messageContainer = document.getElementById('notification-message');

    // Reset spinner and checkmark
    spinner.style.display = 'block';
    checkmark.style.display = 'none';

    // Show the notification with "Processing..." message
    messageContainer.textContent = 'Processing...';
    notification.classList.remove('hidden', 'hide'); // Ensure it's visible
    notification.classList.add('show'); // Trigger the appear animation
    notification.classList.toggle('error', isError); // Toggle error style if needed

    // Handle spinner and checkmark animations
    setTimeout(() => {
        spinner.style.display = 'none'; // Hide spinner
        checkmark.style.display = 'block'; // Show checkmark

        // Update the message to the final content
        messageContainer.textContent = message;
    }, 2000); // Spinner lasts 2 seconds before switching to checkmark

    // Add click event listener to close the notification
    const closeButton = notification.querySelector('.close-btn');
    closeButton.onclick = () => {
        notification.classList.remove('show');
        notification.classList.add('hide'); // Trigger the disappear animation
        setTimeout(() => notification.classList.add('hidden'), 300); // Hide after animation
    };

    // Automatically hide the notification after 5 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        notification.classList.add('hide'); // Trigger the disappear animation
        setTimeout(() => notification.classList.add('hidden'), 300); // Hide after animation
    }, 8000); // Adjust delay for the overall visibility
}
